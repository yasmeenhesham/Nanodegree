# Custom ArrayAdapter Example in Android

This app demonstrates how to create and use a custom ArrayAdapter to display a custom list item view that is more complex than the single TextView supported by the standard ArrayAdapter.

A webcast was recorded that goes through this example code for the Android Developer Nanodegree.
